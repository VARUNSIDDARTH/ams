package com.example.raama.ams;

import android.renderscript.Sampler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class enterotp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enterotp);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Enter OTP");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void check(View view)
    {
        FirebaseDatabase database =FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("otp/otp");

        ValueEventListener listener =new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String s = dataSnapshot.getValue().toString();
                int correctOTP =Integer.parseInt(s);

                EditText editText = findViewById(R.id.entered_otp);
                String a=editText.getText().toString();
                int enteredOTP=Integer.parseInt(a);

                if(enteredOTP== correctOTP)
                {
                    Toast.makeText(enterotp.this,"correct otp",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(enterotp.this,"wrong otp",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                
            }
        };



    }
}
